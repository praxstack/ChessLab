## The platform comes first

In September 2026 the user changed the sequence: build a usable web platform modelled on Chess.com, starting with bot and coach play, then add ChessLab's conversational differentiation. Actual human multiplayer follows the first bot/coach stage. Billing is last. On 8 October 2026 an original-asset policy replaced the reference-parity goal for the hosted beta: the app now uses its own artwork, bot characters and palette. The bot/coach-first sequence is unchanged.

## What can be used

- Play White, Black or random against 43 original bot characters or ten installed engine configurations on a board-first layout, using clicks, dragging or typed moves.
- Review individual moves with engine estimates, legal candidate lines, capture explanations and material consequences. Compare before the selected move to see its candidate arrows.
- Explore both sides of a separate line, nest another variation, save a question with its branch, and return to the original game.
- Save accounts, games, variations, lesson completions and puzzle completions on the same server. Import a legal PGN and export the actual game.
- Use six original introductory lessons and six puzzles. Change orientation, coordinates, legal markers, sounds, playback and bounded analysis preferences.

Open the [local application](http://127.0.0.1:8770) while its server is running. The HTML research archive itself does not run the game. The [application guide](../application.md) contains installation, startup and backup instructions; [ADR 0001](../adr/0001-server-chess-engine.md) explains server-side Stockfish. No engine binary or neural weights are downloaded to the browser.

The current build is [published privately through Sites](https://chesslab-bot-studio.prax-lannister.chatgpt.site). Sign in with the owning ChatGPT account, then create a ChessLab account on its separate hosted database. Native engines run through this Mac’s protected service; the Mac and tunnel must stay running. The owner login, hosted bot reply, saved-game reload and engine-backed position review were verified in the browser. The narrow-window layout was corrected and privately republished.

## What remains

The broader platform is unfinished. There is no human matchmaking, rated ladder, tournament system, social platform, extensive lesson library, subscription checkout or public deployment. Bot levels are not calibrated human ratings. The coach is engine-backed evidence text, not unrestricted conversational AI; questions currently remain learner notes. Saved variations are stored in SQLite and are not included in PGN export.

The original branching conversation remains the intended differentiation. I would judge the next iteration by watching a learner finish a bot game, review one mistake and explain the missed idea without outside help. The current functional checks do not answer that question.

## Current evidence

See the [application verification record](../application-verification.md). It separates automated tests, observed browser behavior, unexecuted checks and unresolved tooling drift. Research-site checks are not product tests.

The source repository is [ChessLab on GitHub](https://github.com/praxstack/ChessLab); access is private. Its creation, commit and push are separate delivery events recorded in the verification note.

## Earlier correction: engines and piece assets

The user challenged the gap between a one-to-one bot clone and the smaller implementation. At that point, only Stockfish 19 was installed and all five levels were presets of it. The expansion below supersedes that inventory. The [application guide](../application.md#engine-inventory-and-difficulty) now gives the exact difficulty mapping and move flow, and lists the missing bot-platform behaviors.

The user also rejected the custom piece drawings. All twelve pieces now use the original images from Chess.com's standard analysis board, served from local files. Green is the default board; Blue remains selectable. This asset correction did not close the bot-personality or platform-parity gaps. It was itself superseded on 8 October 2026: the pieces are now the GPL-licensed cburnett set, the default board is Slate & sand, and the earlier images were removed.

## Expanded bot platform

The current server has Stockfish 19/18/18 Lite/16, Lc0 with its network, Maia3 5M/23M/79M, and Maia2 rapid/blitz weights. Runtime choices are checked for actual readiness. The grouped roster then used 166 observed public bot portraits and ratings with locally implemented behavior; on 8 October 2026 it was replaced by 43 original characters with generated portraits and ratings from the app's own strength ladder. Games now save engine selection, target strength, assistance and clocks. Hints, safe takebacks, contextual scripted chat, adaptive material-based target changes, local crowns and rematches extend the original play/review flow.

The [current application guide](../application.md) explains these controls and the exact limits. Downloaded models stay on the server. The [installation receipt](../../references/engine-installation.json) records sources and hashes. This is product progress over the earlier five-preset baseline, not evidence of full vendor parity, human-rating calibration or learning effectiveness.

## September8 reference mapping

The [current mapping ledger](../research/nonmultiplayer-parity.md) records source contradictions, original assets and remaining implementation gaps. The final46-test suite passes with all ten installed configurations returning legal moves. Board/interface preferences and independent analysis controls now invoke actual behavior. Computer-use inspection also confirmed the reference offers Standard and Chess960; this build implements Standard only. Full non-multiplayer parity remains unfinished.
