# ChessLab

Play a bot, review a decision, try a different line, and return to the actual game.

ChessLab (hosted beta name: AskTheMove) has a web application with a board-first layout, 43 original bot characters with generated portraits, ten installed engine configurations, clocks and assistance, server analysis, saved variations, PGN import/export and accounts on the same server. Six original introductory lessons and six puzzles provide a small practice collection. The coach explains engine evidence. Learner questions are saved notes, not a free-form conversational AI.

The current build follows the user's platform-first direction: bot and coach play first. Human multiplayer and billing are deferred. The app has its own artwork, bot characters, strength ladder and scoring. The full branching conversational tutor remains the longer-term objective.

The pieces are Colin M.L. Burnett's cburnett set (GPL-2.0-or-later) and the navigation icons come from Lucide (ISC). Their licence texts are in `web/public/licenses/`, and Settings lists the credits. Bot portraits are drawn by `scripts/generate_bot_avatars.mjs`.

An optional "Explain why" asks Claude to explain the engine evidence for one position when the server has an Anthropic API key. The server checks each move it cites and otherwise shows the engine summary. [Deploying the private beta](docs/deploy-beta.md) covers the Docker image, invite codes, HTTPS settings and backups for a small hosted beta.

Development and delivery now target the local server. The prior hosted build remains historical. The [local migration and proof guide](docs/local-workspace.md) covers preserved account data, archive routes, the engineering graph, and recorded verification.

## Run the application

Use Node.js 24 or newer and install native Stockfish on the server. On macOS:

```sh
brew install stockfish
npm ci
cp .env.example .env
npm run dev
```

Open [ChessLab at localhost:8770](http://127.0.0.1:8770). Check `STOCKFISH_PATH` in `.env` against `command -v stockfish`, especially on Intel Macs or other operating systems. The server runs Stockfish as a process. It sends moves and analysis to the browser, with no engine or model download.

For the built application:

```sh
npm run build
npm start
```

Read [the application guide](docs/application.md) for accounts, studies, settings, backups, checks and limits. Start with [the product context](CONTEXT.md) and [the current OpenSpec change](openspec/changes/build-coach-web-platform/proposal.md) before changing product behavior.

## Verify changes

```sh
just test       # Setup helper, application and frontend state tests
just app-check  # Application tests and production build
just e2e        # Built app in an isolated database and browser smoke test
just check      # Local skill links/hashes, OpenSpec and whitespace
```

Browser checks use the pinned project Playwright dependency. Run `npx playwright install chromium` once if its browser is missing. Use `just proof` to record a repeatable video with screenshots and a JSON receipt. Agent setup requires Python 3.10+, `just`, OpenSpec and the existing skill sources in `skills.local.json`. These tools are separate from the runtime dependencies. See [the setup guide](docs/agents/setup.md).

The latest setup check stops at a missing installed Pstack `unslop` source. An earlier check also recorded `gstack-cso` entrypoint hash drift. The setup check reports that failure until the changed source is reviewed and the manifest is deliberately updated. Application checks do not waive the setup check. Passing local tests does not establish public deployment, scalable hosting or learning outcomes.

## Research and design archive

The supplied research remains reference material, not governing instructions. Read [the assessment](docs/research/assessment.md), [the archive index](docs/research/archive-index.md), and [the HTML dossier](report/index.html). The dossier records earlier research and setup status. Its historical statements about the absence of an application describe that earlier work.

```sh
just report        # Rebuild HTML from source documents
just report-check  # Verify source/output hashes and local links
just report-test   # Check the reading site in Chromium
just report-zip    # Verify and package the portable site
```

Rebuilding the dossier requires Python 3.10+ and Pandoc. Reading the generated HTML works offline. `ChessLab-dossier.zip` is a portable snapshot and may predate current application work. Rebuild and verify before treating generated reports as current. Never hand-edit derived HTML.

The `design/` directory preserves the mockup gallery and the written frame study and settings inventory. Open `design/index.html` or `design/frame-study.html`; rebuild with `python3 design/build.py` and check with `python3 design/check.py`. These archives explain the visual direction; they are not runtime evidence. Under the original-asset policy adopted on 8 October 2026, the session recording, its extracted frames, the supplied screenshot ZIP and the Chrome reference session were removed from the current tree. Earlier commits still contain them.

The server's Stockfish installation is separate from this repository. See [the engine decision](docs/adr/0001-server-chess-engine.md) for licensing and operational boundaries. The source and research are pushed to the [private ChessLab repository](https://github.com/praxstack/ChessLab). Public hosting remains separate and unfinished.
